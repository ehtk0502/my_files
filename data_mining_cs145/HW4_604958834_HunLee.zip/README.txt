#Name: Hun Lee
#UID: 604958834

contents:

	report: this contains answer to the homework questions
	
	DataPoints.py: source code for the dataPoints logics where i modified mean, stddev, and cov parts

	DBSCAN.py: DB scan source code

	GMM.py: GMM source code

	KMeans.py: kmeans source code

	README: explains what is included in the file