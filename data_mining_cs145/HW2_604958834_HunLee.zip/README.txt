#Name: Hun Lee
#UID: 604958834

contents:

	report: this contains answer to the homework questions
	
	DecisionTree.py: source code for the decision tree part of the homework

	2.py: source code for graphing 2.1 exercise. contains 3D and 2D graphing code.

	svm.py: contains the source code for svm assignment

	README: explains what is included in the file