Hun Lee
604958834

contents:
	apriori.py: source code for the apriori
	report: answer to the questions
	README: list and descriptions of the contents